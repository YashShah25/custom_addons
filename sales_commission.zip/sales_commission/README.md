Project Task Timer
------------------------------------

Odoo Version : Odoo 14.0 Community

Installation
-------------------------------------
Install the Application => Apps -> Sales Commission

Project Task Timer Functionality
---------------------------------------------

Calculates commission automatically and provide history of customer commissions.