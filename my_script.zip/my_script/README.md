Create script to perform below task:
- Add contacts. 
- Set country  “united state”  whose company is “my company(san francisco)”.
- Remove those contacts whose city is “Berlin”.
- At the end print count of partners.

